package org.acme.repository;

import org.acme.entities.Message;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;

@ApplicationScoped
public class Repository {

    @Inject
    private EntityManager em;

    @Transactional
    public Message create(Message m){
        em.persist(m);
        return m;
    }

    public List<Message> getAll(){
        return this.em
                .createNamedQuery("Message.findAll",Message.class)
                .getResultList();
    }
}
