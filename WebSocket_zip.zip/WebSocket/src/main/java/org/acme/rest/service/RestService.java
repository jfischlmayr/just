package org.acme.rest.service;

import org.acme.entities.Message;
import org.acme.repository.Repository;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.List;

@ApplicationScoped
@Path("/service")
public class RestService {

    @Inject
    Repository repo;

    @GET
    @Path("hello")
    @Produces(MediaType.TEXT_PLAIN)
    public String hello() {
        return "Hello RESTEasy";
    }

    @Path("messages")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Message> getMessages()
    {
        return repo.getAll();
    }
}