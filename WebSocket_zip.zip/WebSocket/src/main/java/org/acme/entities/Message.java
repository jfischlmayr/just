package org.acme.entities;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@NamedQueries({
        @NamedQuery(name = "Message.findAll", query = "SELECT m FROM Message m")
})
public class Message {

    @Id
    @GeneratedValue
    private long id;
    private String txt;
    private String usr;
    private LocalDateTime timestamp;

    public Message(){};

    public Message(String txt, String usr, LocalDateTime timestamp)
    {
        this.txt = txt;
        this.usr = usr;
        this.timestamp = timestamp;
    };

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTxt() {
        return txt;
    }

    public void setTxt(String txt) {
        this.txt = txt;
    }

    public String getUsr() {
        return usr;
    }

    public void setUsr(String usr) {
        this.usr = usr;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}
